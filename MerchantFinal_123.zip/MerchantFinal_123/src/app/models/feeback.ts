import { Customer } from "./customer";

import { Merchant } from "./merchant";
import { Product } from "./product";

export class Feedback{

    feedbackId:number;
    customer:Customer;
    product:Product;
    ratingProduct:number;
    ratingMerchant:number;
    comment:string;
    merchant:Merchant;

}