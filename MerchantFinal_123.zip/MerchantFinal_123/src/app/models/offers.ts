export interface Offers{
   
	merchantId:number;
	offerDescription:string;
	productId:number;
	startDate:Date;
	endDate:Date;
	discount:number;
	softDelete:string;
}