import { Merchant } from "./merchant";
import { Offers } from "./offers";

export interface Inventory{
   
    inventoryId:number;
    merchant:Merchant;
    productName:string;
    productCategory:string;
    productPrice:number;
    productModel:string;
    productRating:number;
    discountOffered:number;
    productDescription:string;
    productBrand:string;
    offer:Offers;
    status:string;
    inventoryType:string;
    inventoryQuantity:number;
    imageUrl:string;
   
}