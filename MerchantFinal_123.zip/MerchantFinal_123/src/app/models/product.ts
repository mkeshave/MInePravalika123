import { Offers } from "./Offers";
import { Inventory } from "./Inventory";

export class Product{
   
    productId:number;
    productName:string;
    productPrice:number;
    productQuantity:number;
    discountOffered:number;
    productCategory:string;
    productType:string;
    productBrand:string;
    productModel:string;
    productDescription:string;
    productRating;
    productFeedback;
   
      
    inventory:Inventory;
 
    offer:Offers;
    productsSold:string;
    productView:Offers;
    isPromotionMessageSent:string;

   
    
   
}