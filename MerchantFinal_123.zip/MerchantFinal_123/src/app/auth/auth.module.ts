import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthRoutingModule } from './auth-routing.module';

import { FormsModule } from '@angular/forms';
import { UiModule } from '../ui/ui.module';
import { ManageInventoryComponent } from './manage-inventory/manage-inventory.component';
import { ViewOrdersComponent } from './view-orders/view-orders.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { OfferComponent } from './offers/offer.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { SliderImageComponent } from './slider-image/slider-image.component';
import { UploadImageComponent } from './upload-image/upload-image.component';





@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    AuthRoutingModule,
    UiModule
  ],
  declarations: [ ManageInventoryComponent, ViewOrdersComponent, ChangePasswordComponent, OfferComponent,FeedbackComponent,SliderImageComponent,UploadImageComponent],
})
export class AuthModule {
}
