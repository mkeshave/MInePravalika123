import { Component, OnInit } from '@angular/core';
import { Feedback } from '../../models/feeback';
import { Customer } from '../../models/customer';
import { AppService } from '../../app.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss']
})
export class FeedbackComponent implements OnInit {

  avgRating:number;

  feedback:Feedback=new Feedback();
  feedbacks:Feedback[]=[];


  customer:Customer={
    customerId:0,
    firstName:"",
    lastName:"",
    mobileNumber:"",
      emailId:"",
      password:"",
      address:{
        addressId:0,
         addressLine1:"",
         addressLine2:"",
         city:"",
         state:"",
         pincode:""
       },
      isVerified:true
  }

  constructor(private feedbackService:AppService) { }

  ngOnInit() {

    this.feedbackService.getFeedbacks().subscribe(feedbacks => {
      // if(products.indexOf[0]==null)
      // {
      //   alert("Not Found")
      // }
      
      // else
      this.feedbacks = feedbacks;
      console.log(this.feedbacks);
      
    });
    
    this.feedbackService.getAverageRating().subscribe(avgRating =>{
      this.avgRating=avgRating;
      console.log(this.avgRating);
    })
  }

}
