import { Component, OnInit } from '@angular/core';
import { Offers } from '../../models/offers';
import { AppService } from '../../app.service';

@Component({
  selector: 'app-offer',
  templateUrl: './offer.component.html',
  styleUrls: ['./offer.component.scss']
})
export class OfferComponent implements OnInit {

  offers: Offers = {
    merchantId: 0,
    offerDescription: '',
    productId: 0,
    startDate: null,
    endDate: null,
    discountOffered: 0
  };

  constructor(private _offerService:AppService) { }



  ngOnInit() {
  }

  addOffer(): void {
    console.log(this.offers);
    this._offerService.addOffer(this.offers).subscribe(flag => {
      if (flag) {
        alert("added!");
      }
    });
   
  }
}
