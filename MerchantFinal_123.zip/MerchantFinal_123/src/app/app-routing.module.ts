import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { MainHeaderComponent } from './header/main-header/main-header.component';

const routes: Routes = [
  
  {
    path: 'auth',
    loadChildren: './auth/auth.module#AuthModule',
  },
 
    
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {
}
