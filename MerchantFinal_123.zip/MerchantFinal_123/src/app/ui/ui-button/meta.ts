export type UiButtonColor = 'default' | 'primary';
export type UiButtonSize = 's' | 'm' | 'l';
export type UiButtonGroupDirection = 'row' | 'column';
export type UiButtonType = 'default' | 'size';
